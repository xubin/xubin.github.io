/**  <p>.</p> */
package com.bayss.framework.code;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bayss.iad.entity.ComponentEntity;
import com.bayss.iad.sys.code.CodeBean;

/**
 * <p> CodeSqlUtil.java.</p>
 * <p>Description:  .</p>
 * <p>Company: .</p>
 * <p>@author xubin</p>
 * <p>@version .</p>
 * Nov 14, 2014: 4:40:11 PM
 */
public class CodeSqlUtil {
	public final static String DELETE_STATUS="0";
	public final static String NORMAL_STATUS="1";
	public final static String SPLIT_CHAR="_";
	
	private static final  String SQLCOMMANDTYPE_FUNCTION_INSERT="INSERT";
	private static final  String SQLCOMMANDTYPE_FUNCTION_DELETE="DELETE";
	
	CodeSqlUtil(){
		
	}
	
	/**
	 *<p>Description: 返回不同的codeBean .</p> 
	 *<p>@param obj
	 *<p>@return CodeBean
	 *@since Nov 14, 2014: 3:30:00 PM
	 *@author xubin
	 *@version 1.0
	 */
	public CodeBean generatorPrefixCodeByEntity(Object obj,String sqlCommandType,Connection  connection) {
		CodeBean codeBean=null;
		if(obj instanceof ComponentEntity){
			codeBean = new CodeBean();
//			codeBean.setCodeFirst("ITRS");
//			codeBean.setCodeSecond("01");

			codeBean = new CodeBean();
			codeBean.setCodeFirst("ITRS");
			codeBean.setCodeSecond("02");
			codeBean.setCodeThree("03");
			//codeBean.setCodeFour("04");
			//codeBean.setCodeFive("05");
			//codeBean.setCodeSix("06");
			codeBean.setCodeNum("00000000");
			if(sqlCommandType.equals(SQLCOMMANDTYPE_FUNCTION_INSERT)&&isBlank(((ComponentEntity) obj).getComponentCode())){
			   ((ComponentEntity) obj).setComponentCode(insertCode(obj, codeBean, connection));
			}else if(sqlCommandType.equals(SQLCOMMANDTYPE_FUNCTION_DELETE)&& !isBlank(((ComponentEntity) obj).getComponentCode())){
				updateCodeValueDeletStatus(((ComponentEntity) obj).getComponentCode(),connection);
			}
		}
		return codeBean;
	}
	
	private  String  insertCode(Object obj, CodeBean codeBean, Connection connection) {
		//判断是否有删除的业务编码
		String code =isHaveDeleteCode(codeBean,connection);
		//如果不存在业务编码则
		if(isBlank(code)){
			 getMaxInsert(codeBean, connection);
			 insertCodeValue(codeBean,connection);
		}else{
		//存在删除的业务编码
			 codeBean.setCode(code);
			 updateCodevalue(codeBean, connection);
			 
		}
		return codeBean.getCode();
	}

	/**
	 *<p>Description:是否有删除的业务编码  .</p> 
	 *<p>@param codeBean
	 *<p>@param connection
	 *<p>@return String
	 *@since Nov 14, 2014: 11:00:56 AM
	 *@author xubin
	 *@version 1.0
	 */
	private  synchronized  String isHaveDeleteCode(CodeBean codeBean,Connection connection)  {
		Statement statement=null;
		ResultSet rs = null;
		String code =null;
		int rowCount=0;
		try{
			//查询删除的编码
			 statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			 //statement =connection.createStatement();
	         rs = statement.executeQuery(getInsertHaveDeleteSql(codeBean));
	         rs.last();
	         rowCount = rs.getRow();
	         if(rowCount>0){
	        	
	        	 code=rs.getString("B_CODE");
	        	
	         }
	        // rs.first();
		
		}catch(SQLException e){
			
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(statement != null){
					statement.close();
				}
			}catch(SQLException e){ 
				
			}
			
		}
	 return code;
		
	}
	/**
	 *<p>Description: 业务编码重启用后更新删除状态为正常状态 .</p> 
	 *<p>@param codeBean
	 *<p>@param connection void
	 *@since Nov 14, 2014: 11:15:24 AM
	 *@author xubin
	 *@version 1.0
	 */
	private  void updateCodevalue(CodeBean codeBean,Connection connection) {
		String updateSqlString =getUpdateSqlByCodeAndStatus();
		PreparedStatement pstmt = null;
			try{
				pstmt =connection.prepareStatement(updateSqlString);
				pstmt.setString(1, NORMAL_STATUS);
				pstmt.setString(2, codeBean.getCode());
				
				pstmt.executeUpdate();
			}catch(SQLException ex) {
				
			}finally{
				try {
					
					if (pstmt != null)
						pstmt.close();
				} catch (SQLException e) {
//					log.error(e,e.getCause());
				}
			}
	}
	
	/**
	 *<p>Description:删除试题同时修改业务编码的状态为删除 .</p> 
	 *<p>@param codeBean
	 *<p>@param connection void
	 *@since Nov 14, 2014: 2:46:21 PM
	 *@author xubin
	 *@version 1.0
	 */
	private  void updateCodeValueDeletStatus(String code ,Connection connection) {
		String updateSqlString =getUpdateSqlByCodeAndStatus();
		PreparedStatement pstmt = null;
			try{
				pstmt =connection.prepareStatement(updateSqlString);
				pstmt.setString(1, DELETE_STATUS);
				pstmt.setString(2, code);
				
				pstmt.executeUpdate();
			}catch(SQLException ex) {
				
			}finally{
				try {
					
					if (pstmt != null)
						pstmt.close();
				} catch (SQLException e) {
//					log.error(e,e.getCause());
				}
			}
	}
	
	/**
	 *<p>Description: 获取最大业务编码序列 .</p> 
	 *<p>@param codeBean
	 *<p>@param connection
	 *<p>@return CodeBean
	 *@since Nov 14, 2014: 4:42:11 PM
	 *@author xubin
	 *@version 1.0
	 */
	private synchronized CodeBean getMaxInsert(CodeBean codeBean,Connection connection) {
		Statement statement=null;
		ResultSet rs = null;
		int rowCount=0;
		try {
		    statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            rs = statement.executeQuery(getInsertHaveNotDeleteCodeNumSql(codeBean));
            rs.last();
            rowCount = rs.getInt("rowCount");
            codeBean.setSortNum(rowCount+1);
            codeBean.setCodeSortNum(getCodeNum(codeBean.getCodeNum(), rowCount));
            codeBean.setCode(getCode(codeBean));
            rs.first();
		} catch (SQLException e) {

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e) {

			}

		}
		return codeBean;
	  
	}
	
	/**
	 *<p>Description:  .</p> 
	 *<p>@param codeBean
	 *<p>@return String
	 *@since Nov 15, 2014: 1:05:52 PM
	 *@author xubin
	 *@version 1.0
	 */
	private synchronized  String getCode(CodeBean codeBean){
		StringBuffer code  =new StringBuffer() ;
		if( null!=codeBean.getCodeFirst()){
			code.append(codeBean.getCodeFirst());
			code.append(SPLIT_CHAR);
		} if(!isBlank(codeBean.getCodeSecond())){
			code.append(codeBean.getCodeSecond());
			code.append(SPLIT_CHAR);
		} if(!isBlank(codeBean.getCodeThree())){
			code.append(codeBean.getCodeThree());
			code.append(SPLIT_CHAR);
		} if(!isBlank(codeBean.getCodeFour())){
			code.append(codeBean.getCodeFour());
			code.append(SPLIT_CHAR);
		} if(!isBlank(codeBean.getCodeFive())){
			code.append(codeBean.getCodeFive());
			code.append(SPLIT_CHAR);
		} if(!isBlank(codeBean.getCodeSix())){
			code.append(codeBean.getCodeSix());
			code.append(SPLIT_CHAR);
		} if(!isBlank(codeBean.getCodeSortNum())){
			code.append(codeBean.getCodeSortNum());
		}
		return code.toString();
	}
	
	
	/**
	 *<p>Description:保存code  .</p> 
	 *<p>@param codeBean
	 *<p>@param connection void
	 *@since Nov 14, 2014: 4:43:06 PM
	 *@author xubin
	 *@version 1.0
	 */
	private   void  insertCodeValue(CodeBean codeBean,Connection connection) {
		String insertsqlString =getInsertSql(codeBean);
		PreparedStatement pstmt = null;
			try{
				pstmt =connection.prepareStatement(insertsqlString);
				pstmt.execute();
			}catch(SQLException ex) {
				
			}finally{
				try {
					
					if (pstmt != null)
						pstmt.close();
				} catch (SQLException e) {
					//log.error(e,e.getCause());
				}
			}
		
	}
	
	/**
	 * 
	 *<p>Description:  .</p> 
	 *<p>@param codeBean
	 *<p>@return String
	 *@since Nov 13, 2014: 1:37:17 PM
	 *@author xubin
	 *@version 1.0
	 */
	private  String getInsertSql(CodeBean codeBean) {
	StringBuffer sql = new StringBuffer(" INSERT INTO T_CODE  (CODE_ID,B_CODE,CODE_NUM,SORT_NUM,CODE_FIRST,CODE_SECOND,CODE_THREE,CODE_FOUR,CODE_FIVE,CODE_SIX,CODE_SORT_NUM,STATUS) value ( ");
	if(null !=codeBean){
		//TODO modify 
		sql.append("'" +PkUtil.getUuid()+"'");
		sql.append(",");
		sql.append((isBlank(codeBean.getCode())==true?null:"'"+codeBean.getCode()+"'"));
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeNum())==true?null:"'"+codeBean.getCodeNum()+"'"));
		sql.append(",");
		sql.append(codeBean.getSortNum());
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeFirst())==true?null:("'"+codeBean.getCodeFirst()+"'")));
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeSecond())==true?null:"'"+codeBean.getCodeSecond()+"'"));
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeThree())==true?null:"'"+codeBean.getCodeThree()+"'"));
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeFour())==true?null:"'"+codeBean.getCodeFour()+"'"));
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeFive())==true?null:"'"+codeBean.getCodeFive()+"'"));
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeSix())==true?null:"'"+codeBean.getCodeSix()+"'"));
		sql.append(",");
		sql.append((isBlank(codeBean.getCodeSortNum())==true?null:"'"+codeBean.getCodeSortNum()+"'"));
		sql.append(",");
		sql.append("'"+NORMAL_STATUS+"'");
		sql.append(")");
	}
	
		
		
		return sql.toString();
	}
	/**
	 *<p>Description: 判断字符串是否为空    null return true .</p> 
	 *<p>@param cs
	 *<p>@return boolean
	 *@since Nov 14, 2014: 1:39:04 PM
	 *@author xubin
	 *@version 1.0
	 */
	private   boolean isBlank(CharSequence cs) {
		if (null == cs) {
			return true;
		}
		int length = cs.length();
		for (int i = 0; i < length; i++) {
			if (!Character.isWhitespace(cs.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	/**
	 *<p>Description: 获取插入操作时的最大codenum .</p> 
	 *<p>@param codeBean
	 *<p>@return String
	 *@since Nov 13, 2014: 11:05:27 AM
	 *@author xubin
	 *@version 1.0
	 */
	private   String getInsertHaveNotDeleteCodeNumSql(CodeBean codeBean) {
		StringBuffer sql = new StringBuffer("SELECT MAX(SORT_NUM) as rowCount  FROM T_CODE WHERE  1=1 ");
		if (!isBlank(codeBean.getCodeFirst())) {
			sql.append(" AND CODE_FIRST =" + "'"+ codeBean.getCodeFirst().trim() + "'");
		} 
		if (!isBlank(codeBean.getCodeSecond())) {
			sql.append(" AND CODE_SECOND=" + "'"+ codeBean.getCodeSecond().trim() + "'");
		}  
		if (!isBlank(codeBean.getCodeThree())) {
			sql.append(" AND CODE_THREE=" + "'"+ codeBean.getCodeThree().trim() + "'");
		} 
		if (!isBlank(codeBean.getCodeFour())) {
			sql.append(" AND CODE_FOUR=" + "'" + codeBean.getCodeFour().trim()+ "'");
		}  
		if (!isBlank(codeBean.getCodeFive())) {
			sql.append(" AND CODE_FIVE=" + "'" + codeBean.getCodeFive().trim()+ "'");
		}  
		if (!isBlank(codeBean.getCodeSix())) {
			sql.append(" AND CODE_SIX=" + "'" + codeBean.getCodeSix().trim()+ "'");
		}
		//未删除状态
		sql.append(" AND STATUS='"+NORMAL_STATUS+"'") ;
		return sql.toString();
	}

	private  synchronized String getCodeNum(String code_num,int sortNum)  {
		if(sortNum==0 && code_num.length()>0){
			return (code_num.substring(0, code_num.length()-1))+(sortNum+1);
		}
		if(sortNum>0 &&(sortNum+"").length()<=code_num.length()){
			int length =code_num.length()-((sortNum+1)+"").length() ;
			return (code_num.substring(0,length)==null?sortNum+1+"":(code_num.substring(0,length))+(sortNum+1));
		}
		if((sortNum+"").length()>code_num.length()){
		  //throw new Exception("序列【"+sortNum+"】超过最大位数"+"【"+code_num+"】");
		}
		return null ;
	
	 }

	/**
	 *<p>Description:  .</p> 
	 *<p>@param codeBean
	 *<p>@return String
	 *@since Nov 14, 2014: 1:54:15 PM
	 *@author xubin
	 *@version 1.0
	 */
	private   String getUpdateSqlByCodeAndStatus() {
		StringBuffer sql = new StringBuffer(" update  T_CODE set STATUS=");
		sql.append("?");
		sql.append(" WHERE B_CODE=");
		sql.append("?");
		return sql.toString();
	}

	/**
	 *<p>Description:获取删除的的业务code中最小的  .</p> 
	 *<p>@param codeBean
	 *<p>@return String
	 *@since Nov 13, 2014: 11:06:08 AM
	 *@author xubin
	 *@version 1.0
	 */
	private  String getInsertHaveDeleteSql (CodeBean codeBean) {
	    
		StringBuffer sql = new StringBuffer("SELECT MIN(SORT_NUM)   FROM T_CODE WHERE  1=1 ");
		if (!isBlank(codeBean.getCodeFirst())) {
			sql.append(" AND CODE_FIRST =" + "'"+ codeBean.getCodeFirst().trim() + "'");
		}  if (!isBlank(codeBean.getCodeSecond())) {
			sql.append(" AND CODE_SECOND=" + "'"+ codeBean.getCodeSecond().trim() + "'");
		}  if (!isBlank(codeBean.getCodeThree())) {
			sql.append(" AND CODE_THREE=" + "'"+ codeBean.getCodeThree().trim() + "'");
		}  if (!isBlank(codeBean.getCodeFour())) {
			sql.append(" AND CODE_FOUR=" + "'" + codeBean.getCodeFour().trim()+ "'");
		}  if (!isBlank(codeBean.getCodeFive())) {
			sql.append(" AND CODE_FIVE=" + "'" + codeBean.getCodeFive().trim()+ "'");
		}  if (!isBlank(codeBean.getCodeSix())) {
			sql.append(" AND CODE_SIX=" + "'" + codeBean.getCodeSix().trim()+ "'");
		}
		//删除状态的
		sql.append(" AND STATUS='"+DELETE_STATUS+"'") ;
		sql.insert(0, "SELECT  B_CODE  FROM  T_CODE WHERE  SORT_NUM=(") ;
		sql.append(")");
		return sql.toString();
	}
	

}
